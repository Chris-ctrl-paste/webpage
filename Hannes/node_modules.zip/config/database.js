module.exports = {
    database: "mongodb+srv://Hannes:hannes1337@cluster2-ymnrv.mongodb.net/content"
}